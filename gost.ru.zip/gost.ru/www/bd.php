<?php

$name="gost";
$user="root";
$password='';
$host="localhost";
$link=mysqli_connect($host, $user, $password, $name) or die("Невозможно подключиться к БД");

?>